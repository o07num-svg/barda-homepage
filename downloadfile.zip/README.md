# 바르다 공식 홈페이지 — 무료 GitHub Pages 배포용

Hatchable v12의 공개 페이지를 바탕으로 구성한 **무료 정적 웹사이트 이전본**입니다.
메인 브랜드 디자인, 공식 로고, 지점 사진과 주소, 하단 전화 상담을 유지합니다.

## GitHub Pages 설정
1. 이 ZIP을 압축 해제합니다.
2. `index.html`, `style.css`, `logo-original.png`, `branch-head-office.webp`, `branch-pyeongtaek.webp` 파일 **5개**를 저장소 루트에 업로드하고 Commit changes를 누릅니다.
3. GitHub 저장소의 Settings → Pages → Build and deployment → Deploy from a branch를 선택합니다.
4. Branch `main`, Folder `/(root)`를 선택한 뒤 Save를 누릅니다.
5. 사이트 주소: https://o07num-svg.github.io/barda-homepage/

## 중요: 온라인 상담 신청
원본 Hatchable의 상담 신청은 서버/API 및 개인정보 DB를 사용합니다.
GitHub Pages는 정적 호스팅이므로, 개인정보를 잘못 접수하지 않도록
**온라인 신청 양식은 임시 안내 영역으로 대체**했습니다.
전화 상담은 010-3720-6033으로 연결됩니다.
온라인 신청서의 재개는 별도 서버/폼 서비스 연결과 개인정보 처리 확인 후 진행해야 합니다.

## 참고
원본 Hatchable 홈페이지의 파일을 기반으로 재구성한 정적 배포용 버전입니다.
CSS/HTML은 GitHub Pages 경로에 맞게 정리했으며, 원본 사이트와 픽셀 단위 완전 동일함을 보장하지 않습니다.
